import javax.swing.*;
import java.awt.*;
import java.util.Random;


public class Barco extends JFrame {

    private int barcoSeleccionado = -1; // -1 significa que no se ha seleccionado ningún barco
    private boolean vertical = false; // Indica si el barco se debe colocar de forma vertical o horizontal
    private int[][] barcosColocados = new int[5][2]; // Indica los barcos colocados en el tablero 1 (tipo, tamaño)
    private int[] TAMANOS = {2, 3, 3, 4, 5}; // Tamaños de los barcos
    private int[] barcosRestantes = {1, 1, 1, 1, 1}; // Barcos restantes por tipo

    Tablero tablero;

    public Barco() {
        tablero = new Tablero();
    }


    // Método para resetear el barco seleccionado si ya estaba colocado
    public void resetBarco(int barcoIndex) {
        JButton[][] tablero1 = tablero.getTablero1();
        boolean[][] ocupado1 = new boolean[10][10];;

        if (barcosColocados[barcoIndex][0] != 0) {
            int size = TAMANOS[barcoIndex];
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    if (tablero1[i][j].getBackground() == Color.BLACK) {
                        tablero1[i][j].setBackground(Color.BLUE);
                        ocupado1[i][j] = false;
                    }
                }
            }
            barcosColocados[barcoIndex][0] = 0;
            barcosRestantes[barcoIndex] = 1;
        }
    }

    // Método para colocar un barco en el tablero
    public void colocarBarco(int fila, int columna, JButton[][] tablero, boolean[][] ocupado, int size) {
        //JPanel panelBarcos = new JPanel(new GridLayout(5, 1));
        JButton[] barcos;
        barcos = new JButton[5];
        barcos[0] = new JButton("Barco 2");
        barcos[1] = new JButton("Barco 3");
        barcos[2] = new JButton("Barco 3");
        barcos[3] = new JButton("Barco 4");
        barcos[4] = new JButton("Barco 5");
        //barcos = tablero.getBarcos();

        if (barcosColocados[barcoSeleccionado][0] == 0) { // Verificar si el barco seleccionado ya ha sido colocado
            if (vertical) {
                if (fila + size <= 10 && !hayColision(fila, columna, size, true, ocupado)) {
                    for (int i = fila; i < fila + size; i++) {
                        tablero[i][columna].setBackground(Color.BLACK);
                        ocupado[i][columna] = true;
                    }
                    barcosRestantes[barcoSeleccionado]--;
                    if (barcosRestantes[barcoSeleccionado] == 0) {
                        barcos[barcoSeleccionado].setEnabled(false);
                    }
                    barcosColocados[barcoSeleccionado][0] = 1;
                    barcosColocados[barcoSeleccionado][1] = size;
                } else {
                    JOptionPane.showMessageDialog(this, "No se puede colocar el barco aquí", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                if (columna + size <= 10 && !hayColision(fila, columna, size, false, ocupado)) {
                    for (int j = columna; j < columna + size; j++) {
                        tablero[fila][j].setBackground(Color.BLACK);
                        ocupado[fila][j] = true;
                    }
                    barcosRestantes[barcoSeleccionado]--;
                    if (barcosRestantes[barcoSeleccionado] == 0) {
                        barcos[barcoSeleccionado].setEnabled(false);
                    }
                    barcosColocados[barcoSeleccionado][0] = 1;
                    barcosColocados[barcoSeleccionado][1] = size;
                } else {
                    JOptionPane.showMessageDialog(this, "No se puede colocar el barco aquí", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Ya has colocado este tipo de barco", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    // Método para verificar si hay colisión al colocar un barco
    public boolean hayColision(int fila, int columna, int size, boolean vertical, boolean[][] ocupado) {
        if (vertical) {
            for (int i = fila; i < fila + size; i++) {
                if (ocupado[i][columna]) {
                    return true;
                }
            }
        } else {
            for (int j = columna; j < columna + size; j++) {
                if (ocupado[fila][j]) {
                    return true;
                }
            }
        }
        return false;
    }

    // Método para colocar barcos aleatorios en el tablero
    public void colocarBarcosAleatorios(JButton[][] tablero, boolean[][] ocupado) {
        Random rand = new Random();
        for (int k = 0; k < 5; k++) {
            int i = rand.nextInt(10);
            int j = rand.nextInt(10);
            int size = TAMANOS[k];
            boolean vertical = rand.nextBoolean();
            if (vertical) {
                if (i + size <= 10 && !hayColision(i, j, size, true, ocupado)) {
                    for (int l = i; l < i + size; l++) {
                        tablero[l][j].setBackground(Color.BLACK);
                        ocupado[l][j] = true;
                    }
                } else {
                    k--;
                }
            } else {
                if (j + size <= 10 && !hayColision(i, j, size, false, ocupado)) {
                    for (int l = j; l < j + size; l++) {
                        tablero[i][l].setBackground(Color.BLACK);
                        ocupado[i][l] = true;
                    }
                } else {
                    k--;
                }
            }
        }
    }




    public int getBarcoSeleccionado() {
        return barcoSeleccionado;
    }

    public void setBarcoSeleccionado(int barcoSeleccionado) {
        this.barcoSeleccionado = barcoSeleccionado;
    }

    public int[] getBarcosRestantes() {
        return barcosRestantes;
    }

    public void setBarcosRestantes(int[] barcosRestantes) {
        this.barcosRestantes = barcosRestantes;
    }

    public int[] getTAMANOS() {
        return TAMANOS;
    }

    public boolean isVertical() {
        return vertical;
    }

    public void setVertical(boolean vertical) {
        this.vertical = vertical;
    }

    public int[][] getBarcosColocados() {
        return barcosColocados;
    }

    public void setBarcosColocados(int[][] barcosColocados) {
        this.barcosColocados = barcosColocados;
    }
}

