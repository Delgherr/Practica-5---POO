import javax.swing.*;
import java.awt.*;
import java.util.Random;


public class Juego extends JFrame {



    private int ultimoDisparoX = -1;
    private int ultimoDisparoY = -1;
    private boolean seguirDisparando = false;
    private boolean direccionHorizontal = false;
    private boolean direccionVertical = false;
    private Random random = new Random();

    private JButton[][] tablero1;

    public Juego(Tablero tablero) {
        this.tablero1 = tablero.getTablero1();
    }




    // Método para realizar un ataque en el tablero
    public void atacar(int fila, int columna, JButton[][] tablero) {
        if (tablero[fila][columna].getBackground() != Color.RED && tablero[fila][columna].getBackground() != Color.WHITE) {
            if (tablero[fila][columna].getBackground() == Color.BLACK) {
                tablero[fila][columna].setBackground(Color.RED);
                comprobarGanador(tablero);
            } else {
                tablero[fila][columna].setBackground(Color.WHITE);
            }
        }
    }

    // Método para comprobar si el jugador ha ganado
    public void comprobarGanador(JButton[][] tablero) {
        boolean ganador = true;
        JButton[][] tablero2 = new JButton[10][10];
        //JButton[][] tablero2 = tablero.getTablero2();

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (tablero[i][j].getBackground() == Color.BLACK) {
                    ganador = false;
                    break;
                }
            }
        }
        if (ganador) {
            JOptionPane.showMessageDialog(this, "Fin de la partida", "Fin", JOptionPane.INFORMATION_MESSAGE);
            bloquearBotones(tablero2);
        }
    }

    // Método para bloquear botones después de comenzar la partida
    public void bloquearBotones(JButton[][] tablero) {
        // Bloquear botones
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[i].length; j++) {
                JButton boton = tablero[i][j];
                if (boton != null) {
                    boton.setEnabled(false);
                }
            }
        }
    }

   public void turnoComputadora() {
        int fila, columna;

        if (seguirDisparando && ultimoDisparoX != -1 && ultimoDisparoY != -1) {
            if (direccionHorizontal) {
                columna = ultimoDisparoY + 1;
                fila = ultimoDisparoX;
                while (columna < 10 && tablero1[fila][columna].getBackground() == Color.RED) {
                    columna++;
                }
                if (columna < 10) {
                    atacar(fila, columna, tablero1);
                    if (tablero1[fila][columna].getBackground() == Color.RED) {
                        direccionHorizontal = false;
                    }
                    ultimoDisparoY = columna;
                    return;
                } else {
                    direccionHorizontal = false;
                    seguirDisparando = false;
                    turnoComputadora();
                    return;
                }
            } else if (direccionVertical) {
                fila = ultimoDisparoX + 1;
                columna = ultimoDisparoY;
                while (fila < 10 && tablero1[fila][columna].getBackground() == Color.RED) {
                    fila++;
                }
                if (fila < 10) {
                    atacar(fila, columna, tablero1);
                    if (tablero1[fila][columna].getBackground() == Color.RED) {
                        direccionVertical = false;
                    }
                    ultimoDisparoX = fila;
                    return;
                } else {
                    direccionVertical = false;
                    seguirDisparando = false;
                    turnoComputadora();
                    return;
                }
            }
        }

        if (seguirDisparando) {
            // Ataque estratégico alrededor del último disparo exitoso
            int[] vecinosX = {0, 0, 1, -1};
            int[] vecinosY = {1, -1, 0, 0};
            for (int i = 0; i < 4; i++) {
                int nuevoX = ultimoDisparoX + vecinosX[i];
                int nuevoY = ultimoDisparoY + vecinosY[i];
                if (nuevoX >= 0 && nuevoX < 10 && nuevoY >= 0 && nuevoY < 10) {
                    if (tablero1[nuevoX][nuevoY].getBackground() != Color.RED && tablero1[nuevoX][nuevoY].getBackground() != Color.WHITE) {
                        atacar(nuevoX, nuevoY, tablero1);
                        return;
                    }
                }
            }
        }

        do {
            fila = random.nextInt(10);
            columna = random.nextInt(10);
        } while (tablero1[fila][columna].getBackground() == Color.RED || tablero1[fila][columna].getBackground() == Color.WHITE);

        if (tablero1[fila][columna].getBackground() == Color.BLACK) {
            tablero1[fila][columna].setBackground(Color.RED);
            ultimoDisparoX = fila;
            ultimoDisparoY = columna;
            seguirDisparando = true;
            comprobarGanador(tablero1);
        } else {
            tablero1[fila][columna].setBackground(Color.WHITE);
        }
    }


    public Random getRandom() {
        return random;
    }
    public void setRandom(Random random) {
        this.random = random;
    }
    public int getUltimoDisparoX() {
        return ultimoDisparoX;
    }
    public void setUltimoDisparoX(int ultimoDisparoX) {
        this.ultimoDisparoX = ultimoDisparoX;
    }
    public int getUltimoDisparoY() {
        return ultimoDisparoY;
    }
    public void setUltimoDisparoY(int ultimoDisparoY) {
        this.ultimoDisparoY = ultimoDisparoY;
    }
    public boolean isSeguirDisparando() {
        return seguirDisparando;
    }
    public void setSeguirDisparando(boolean seguirDisparando) {
        this.seguirDisparando = seguirDisparando;
    }
    public boolean isDireccionHorizontal() {
        return direccionHorizontal;
    }
    public void setDireccionHorizontal(boolean direccionHorizontal) {
        this.direccionHorizontal = direccionHorizontal;
    }
    public boolean isDireccionVertical() {
        return direccionVertical;
    }
    public void setDireccionVertical(boolean direccionVertical) {
        this.direccionVertical = direccionVertical;
    }

}

