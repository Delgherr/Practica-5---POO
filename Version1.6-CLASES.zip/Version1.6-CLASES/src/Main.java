import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        // Crear instancias de las clases Tablero y Juego
        Tablero tablero = new Tablero();
        //Juego juego = new Juego();

        // Configurar el juego para que tenga una referencia al tablero
        //juego.setTablero(tablero);

        // Configurar y mostrar el tablero
        tablero.setVisible(true);

        // Mostrar un mensaje de bienvenida
        JOptionPane.showMessageDialog(null, "¡Bienvenido al juego de Batalla Naval!");
    }
}
