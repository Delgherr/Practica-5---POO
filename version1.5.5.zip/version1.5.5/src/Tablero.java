import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Tablero extends JFrame {

    private JButton[][] tablero1;
    private JButton[][] tablero2;
    private JButton[] barcos;
    private JButton comenzarPartida;
    private JButton rotar;

    private int barcoSeleccionado = -1; // -1 significa que no se ha seleccionado ningún barco
    private boolean vertical = false; // Indica si el barco se debe colocar de forma vertical o horizontal

    private boolean[][] ocupado1 = new boolean[10][10]; // Indica si una celda del tablero 1 está ocupada
    private boolean[][] ocupado2 = new boolean[10][10]; // Indica si una celda del tablero 2 está ocupada

    private int[][] barcosColocados = new int[5][2]; // Indica los barcos colocados en el tablero 1 (tipo, tamaño)

    private final int[] TAMANOS = {2, 3, 3, 4, 5}; // Tamaños de los barcos
    private int[] barcosRestantes = {1, 1, 1, 1, 1}; // Barcos restantes por tipo

    private Random random = new Random();

    private int ultimoDisparoX = -1;
    private int ultimoDisparoY = -1;
    private boolean seguirDisparando = false;
    private boolean direccionHorizontal = false;
    private boolean direccionVertical = false;

    public Tablero() {
        setTitle("Tablero de Batalla");
        setSize(1000, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear tableros
        JPanel panelTablero1 = new JPanel(new GridLayout(10, 10));
        JPanel panelTablero2 = new JPanel(new GridLayout(10, 10));

        tablero1 = new JButton[10][10];
        tablero2 = new JButton[10][10];

        // Crear botones de barcos
        JPanel panelBarcos = new JPanel(new GridLayout(5, 1));
        barcos = new JButton[5];
        barcos[0] = new JButton("Barco 2");
        barcos[1] = new JButton("Barco 3");
        barcos[2] = new JButton("Barco 3");
        barcos[3] = new JButton("Barco 4");
        barcos[4] = new JButton("Barco 5");

        for (JButton barco : barcos) {
            panelBarcos.add(barco);
            barco.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int indiceBarco = getIndex(barcos, barco);
                    if (barcosRestantes[indiceBarco] > 0) {
                        if (barcoSeleccionado != indiceBarco) {
                            barcoSeleccionado = indiceBarco;
                            resetBarco(barcoSeleccionado);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Ya no quedan barcos de este tipo.", "Atención", JOptionPane.WARNING_MESSAGE);
                    }
                }
            });
        }

        // Agregar botones al tablero
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                tablero1[i][j] = new JButton();
                tablero1[i][j].setBackground(Color.BLUE);
                int finalI = i;
                int finalJ = j;
                tablero1[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (barcoSeleccionado != -1 && comenzarPartida.isEnabled()) {
                            colocarBarco(finalI, finalJ, tablero1, ocupado1, TAMANOS[barcoSeleccionado]);
                        }
                    }
                });
                panelTablero1.add(tablero1[i][j]);

                tablero2[i][j] = new JButton();
                tablero2[i][j].setBackground(new Color(01, 01, 01)); // Gris oscuro
                int finalI1 = i;
                int finalJ1 = j;
                tablero2[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (!comenzarPartida.isEnabled()) {
                            atacar(finalI1, finalJ1, tablero2);
                            turnoComputadora();
                        }
                    }
                });
                panelTablero2.add(tablero2[i][j]);
            }
        }

        // Crear contenedor para los tableros
        JPanel tablerosPanel = new JPanel(new GridLayout(1, 2));
        tablerosPanel.add(panelTablero1);
        tablerosPanel.add(panelTablero2);

        // Añadir componentes al frame
        add(tablerosPanel, BorderLayout.CENTER);
        add(panelBarcos, BorderLayout.WEST);

        /// Agregar botón de rotación
        rotar = new JButton("Rotar");
        rotar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (barcoSeleccionado != -1) { // Verificar si se ha seleccionado un barco
                    vertical = !vertical;
                    resetBarco(barcoSeleccionado); // Restablecer el barco seleccionado al rotar
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, seleccione un barco antes de rotarlo.", "Atención", JOptionPane.WARNING_MESSAGE);
                }
            }
        });






        // Botón para comenzar la partida
        comenzarPartida = new JButton("Comenzar Partida");
        comenzarPartida.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                comenzarPartida.setEnabled(false);
                rotar.setEnabled(false);
                for (JButton barco : barcos) {
                    barco.setEnabled(false);
                }
                colocarBarcosAleatorios(tablero2, ocupado2);
            }
        });

        JPanel botonesPanel = new JPanel();
        botonesPanel.add(rotar);
        botonesPanel.add(comenzarPartida);

        add(botonesPanel, BorderLayout.SOUTH);
    }

    // Función para obtener el índice de un JButton en un array
    private int getIndex(JButton[] array, JButton button) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == button) {
                return i;
            }
        }
        return -1;
    }

    // Método para resetear el barco seleccionado si ya estaba colocado
    private void resetBarco(int barcoIndex) {
        if (barcosColocados[barcoIndex][0] != 0) {
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    if (tablero1[i][j].getBackground() == Color.BLACK) {
                        tablero1[i][j].setBackground(Color.BLUE);
                        ocupado1[i][j] = false;
                    }
                }
            }
            barcosColocados[barcoIndex][0] = 0;
            barcosRestantes[barcoIndex] = 1;
        }
    }


    // Método para colocar un barco en el tablero
    private void colocarBarco(int fila, int columna, JButton[][] tablero, boolean[][] ocupado, int size) {
        if (barcosColocados[barcoSeleccionado][0] == 0) { // Verificar si el barco seleccionado ya ha sido colocado
            if (vertical) {
                if (fila + size <= 10 && !hayColision(fila, columna, size, true, ocupado)) {
                    for (int i = fila; i < fila + size; i++) {
                        tablero[i][columna].setBackground(Color.BLACK);
                        ocupado[i][columna] = true;
                    }
                    barcosRestantes[barcoSeleccionado]--;
                    if (barcosRestantes[barcoSeleccionado] == 0) {
                        barcos[barcoSeleccionado].setEnabled(false);
                    }
                    barcosColocados[barcoSeleccionado][0] = 1;
                    barcosColocados[barcoSeleccionado][1] = size;
                } else {
                    JOptionPane.showMessageDialog(this, "No se puede colocar el barco aquí", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                if (columna + size <= 10 && !hayColision(fila, columna, size, false, ocupado)) {
                    for (int j = columna; j < columna + size; j++) {
                        tablero[fila][j].setBackground(Color.BLACK);
                        ocupado[fila][j] = true;
                    }
                    barcosRestantes[barcoSeleccionado]--;
                    if (barcosRestantes[barcoSeleccionado] == 0) {
                        barcos[barcoSeleccionado].setEnabled(false);
                    }
                    barcosColocados[barcoSeleccionado][0] = 1;
                    barcosColocados[barcoSeleccionado][1] = size;
                } else {
                    JOptionPane.showMessageDialog(this, "No se puede colocar el barco aquí", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Ya has colocado este tipo de barco", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    // Método para verificar si hay colisión al colocar un barco
    private boolean hayColision(int fila, int columna, int size, boolean vertical, boolean[][] ocupado) {
        if (vertical) {
            for (int i = fila; i < fila + size; i++) {
                if (ocupado[i][columna]) {
                    return true;
                }
            }
        } else {
            for (int j = columna; j < columna + size; j++) {
                if (ocupado[fila][j]) {
                    return true;
                }
            }
        }
        return false;
    }

    // Método para colocar barcos aleatorios en el tablero
    private void colocarBarcosAleatorios(JButton[][] tablero, boolean[][] ocupado) {
        Random rand = new Random();
        for (int k = 0; k < 5; k++) {
            int i = rand.nextInt(10);
            int j = rand.nextInt(10);
            int size = TAMANOS[k];
            boolean vertical = rand.nextBoolean();
            if (vertical) {
                if (i + size <= 10 && !hayColision(i, j, size, true, ocupado)) {
                    for (int l = i; l < i + size; l++) {
                        tablero[l][j].setBackground(Color.BLACK);
                        ocupado[l][j] = true;
                    }
                } else {
                    k--;
                }
            } else {
                if (j + size <= 10 && !hayColision(i, j, size, false, ocupado)) {
                    for (int l = j; l < j + size; l++) {
                        tablero[i][l].setBackground(Color.BLACK);
                        ocupado[i][l] = true;
                    }
                } else {
                    k--;
                }
            }
        }
    }

    // Método para realizar un ataque en el tablero
    private void atacar(int fila, int columna, JButton[][] tablero) {
        if (tablero[fila][columna].getBackground() != Color.RED && tablero[fila][columna].getBackground() != Color.WHITE) {
            if (tablero[fila][columna].getBackground() == Color.BLACK) {
                tablero[fila][columna].setBackground(Color.RED);
                comprobarGanador(tablero);
            } else {
                tablero[fila][columna].setBackground(Color.WHITE);
            }
        }
    }

    // Método para comprobar si el jugador ha ganado
    private void comprobarGanador(JButton[][] tablero) {
        boolean ganador = true;
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (tablero[i][j].getBackground() == Color.BLACK) {
                    ganador = false;
                    break;
                }
            }
        }
        if (ganador) {
            JOptionPane.showMessageDialog(this, "¡Juego Finalizado!", "Ganador", JOptionPane.INFORMATION_MESSAGE);
            bloquearBotones(tablero2);
        }
    }

    // Método para bloquear botones después de terminar la partida
    private void bloquearBotones(JButton[][] tablero) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                tablero[i][j].setEnabled(false);
            }
        }
    }

    private void turnoComputadora() {
        int fila, columna;

        if (seguirDisparando && ultimoDisparoX != -1 && ultimoDisparoY != -1) {
            if (direccionHorizontal) {
                columna = ultimoDisparoY + 1;
                fila = ultimoDisparoX;
                while (columna < 10 && tablero1[fila][columna].getBackground() == Color.RED) {
                    columna++;
                }
                if (columna < 10) {
                    atacar(fila, columna, tablero1);
                    if (tablero1[fila][columna].getBackground() == Color.RED) {
                        direccionHorizontal = false;
                    }
                    ultimoDisparoY = columna;
                    return;
                } else {
                    direccionHorizontal = false;
                    seguirDisparando = false;
                    turnoComputadora();
                    return;
                }
            } else if (direccionVertical) {
                fila = ultimoDisparoX + 1;
                columna = ultimoDisparoY;
                while (fila < 10 && tablero1[fila][columna].getBackground() == Color.RED) {
                    fila++;
                }
                if (fila < 10) {
                    atacar(fila, columna, tablero1);
                    if (tablero1[fila][columna].getBackground() == Color.RED) {
                        direccionVertical = false;
                    }
                    ultimoDisparoX = fila;
                    return;
                } else {
                    direccionVertical = false;
                    seguirDisparando = false;
                    turnoComputadora();
                    return;
                }
            }
        }


        if (seguirDisparando) {
            // Ataque estratégico alrededor del último disparo exitoso
            int[] vecinosX = {0, 0, 1, -1};
            int[] vecinosY = {1, -1, 0, 0};
            for (int i = 0; i < 4; i++) {
                int nuevoX = ultimoDisparoX + vecinosX[i];
                int nuevoY = ultimoDisparoY + vecinosY[i];
                if (nuevoX >= 0 && nuevoX < 10 && nuevoY >= 0 && nuevoY < 10) {
                    if (tablero1[nuevoX][nuevoY].getBackground() != Color.RED && tablero1[nuevoX][nuevoY].getBackground() != Color.WHITE) {
                        atacar(nuevoX, nuevoY, tablero1);
                        return;
                    }
                }
            }
        }

        do {
            fila = random.nextInt(10);
            columna = random.nextInt(10);
        } while (tablero1[fila][columna].getBackground() == Color.RED || tablero1[fila][columna].getBackground() == Color.WHITE);

        if (tablero1[fila][columna].getBackground() == Color.BLACK) {
            tablero1[fila][columna].setBackground(Color.RED);
            ultimoDisparoX = fila;
            ultimoDisparoY = columna;
            seguirDisparando = true;
            comprobarGanador(tablero1);
        } else {
            tablero1[fila][columna].setBackground(Color.WHITE);
        }
    }



}
