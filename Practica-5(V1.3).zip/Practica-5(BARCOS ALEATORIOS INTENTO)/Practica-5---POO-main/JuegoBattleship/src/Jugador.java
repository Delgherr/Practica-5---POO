import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class Jugador {
    private Barco[] barcos;
    private int[][] tableroM = new int[11][11];

    public Jugador() {
        this.barcos = new Barco[5];
    }

    public void crearBarcosAleatorios(JPanel panel, String[] rutasImagenes) {
        Random rand = new Random();
        for (int i = 0; i < 5; i++) {
            int size = i + 2;
            boolean colocado = false;
            while (!colocado) {
                int x = rand.nextInt(10) + 1;
                int y = rand.nextInt(10) + 1;
                boolean horizontal = true;
                if (puedeColocarHorizontal(size, x, y)) {
                    crearBarco(panel, rutasImagenes[i], size, x, y);
                    colocado = true;
                }
            }
        }
    }

    private boolean puedeColocarHorizontal(int size, int x, int y) {
        if (y + size > 11) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (tableroM[x][y + i] != 0) {
                return false;
            }
        }
        return true;
    }

    private void crearBarco(JPanel panel, String rutaImagen, int size, int x, int y) {
        Barco barco = new Barco(((x - 1) * 31.09) + 32, ((y - 1) * 31.09) + 32, 100, 50, size, rutaImagen, panel, false); // Cambiado tamaño de altura y ancho, y rotado a false
        barcos[size - 2] = barco;

        for (int i = 0; i < size; i++) {
            tableroM[x][y + i] = 1;
        }
    }

    public Barco[] getBarcos() {
        return barcos;
    }

    public void setBarcos(Barco[] barcos) {
        this.barcos = barcos;
    }

    //Al momneto en que se crea un codigo
    private void crearBarco(JPanel panel, String rutaImagen, int size, int x, int y, boolean horizontal) {
        Barco barco = new Barco(((x - 1) * 31.09) + 32, ((y - 1) * 31.09) + 32, 50, 100, size, rutaImagen, panel, horizontal);
        if (barco.dentroDeLimites(x, y, horizontal)) {
            barcos[size - 2] = barco;

            for (int i = 0; i < size; i++) {
                if (horizontal) {
                    tableroM[x][y + i] = 1;
                } else {
                    tableroM[x + i][y] = 1;
                }
            }
        } else {
            System.out.println("El barco no cabe en esta posición. Intente de nuevo.");
        }
    }
    private void crearBarcoHorizontal(JPanel panel, String rutaImagen, int size, int x, int y, boolean horizontal) {
        Barco barco = new Barco(((x - 1) * 31.09) + 32, ((y - 1) * 31.09) + 32, 50, 100, size, rutaImagen, panel, horizontal);
        if (barco.dentroDeLimitesHorizontal(x, y, horizontal)) {
            // Colocar el barco
            System.out.println("Barco colocado en posición válida.");
        } else {
            System.out.println("El barco no cabe en esta posición. Intente de nuevo.");
        }
    }

    //evitar que se traslapen los barcos
    private boolean puedeColocarBarco(int size, int x, int y, boolean horizontal) {
        if (horizontal) {
            if (x < 0 || x >= 10 || y < 0 || y >= 10 || x + size > 10) {
                return false;
            }

            for (int i = x; i < x + size; i++) {
                if (tableroM[i][y] != 0) {
                    return false;
                }
            }
        } else {
            if (x < 0 || x >= 10 || y < 0 || y >= 10 || y + size > 10) {
                return false;
            }

            for (int i = y; i < y + size; i++) {
                if (tableroM[x][i] != 0) {
                    return false;
                }
            }
        }
        return true;
    }




}
