import javax.swing.*;
import java.awt.*;

public class Barco {
    private double posX;
    private double posY;
    private double altura;
    private double ancho;
    private int size;
    private ImageIcon imagen;
    private JPanel panel;
    private boolean rotated = false;

    public Barco(double posX, double posY, String rutaImagen, JPanel panel) {
        this.posX = posX;
        this.posY = posY;
        this.imagen = new ImageIcon(rutaImagen);
        this.panel = panel;
    }

    public Barco(double posX, double posY, double altura, double ancho, int size, String rutaImagen, JPanel panel, boolean rotated) {
        this(posX, posY, rutaImagen, panel);
        this.altura = altura;
        this.ancho = ancho;
        this.size = size;
        this.rotated = rotated;
    }

    public void paint(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        if (rotated) {
            g2d.rotate(Math.toRadians(90), posX + imagen.getIconWidth() / 2, posY + imagen.getIconHeight() / 2);
        }
        g2d.drawImage(imagen.getImage(), (int) posX, (int) posY, null);
        g2d.dispose();
    }

    public double getPosX() {
        return posX;
    }

    public void setPosX(double posX) {
        this.posX = posX;
    }

    public double getPosY() {
        return posY;
    }

    public void setPosY(double posY) {
        this.posY = posY;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public ImageIcon getImagen() {
        return imagen;
    }

    public void setImagen(ImageIcon imagen) {
        this.imagen = imagen;
    }

    public boolean isRotated() {
        return rotated;
    }

    public void setRotated(boolean rotated) {
        this.rotated = rotated;
    }

    public boolean contains(Point p) {
        int x = (int) posX;
        int y = (int) posY;
        int width = imagen.getIconWidth();
        int height = imagen.getIconHeight();
        Rectangle bounds = new Rectangle(x, y, width, height);
        return bounds.contains(p);
    }

    public boolean dentroDeLimites(int x, int y, boolean horizontal) {
        if (horizontal) {
            return x >= 0 && x + size <= 10 && y >= 0 && y < 10;
        } else {
            return x >= 0 && x < 10 && y >= 0 && y + size <= 10;
        }
    }

    public boolean dentroDeLimitesHorizontal(int x, int y, boolean horizontal) {
        if (horizontal) {
            return x >= 0 && x + size - 1 < 10 && y >= 0 && y < 10;
        } else {
            return x >= 0 && x < 10 && y >= 0 && y + size - 1 < 10;
        }
    }
}
