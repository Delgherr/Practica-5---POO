import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class Jugador {
    private Barco[] barcos;
    private int[][] tableroM = new int[11][11];

    public Jugador() {
        this.barcos = new Barco[5];
    }

    /*public void crearBarcos(JPanel panel, String[] rutasImagenes, int[] posicionesX, int[] posicionesY) {
        for (int i = 0; i < 5; i++) {
            Barco barco = new Barco(posicionesX[i], posicionesY[i], 50, 100, 5, rutasImagenes[i], panel);
            barcos[i] = barco;
        }

        Barco barco = new Barco(posicionesX[0], posicionesY[0], 50, 100, 2, rutasImagenes[0], panel);
        barcos[0] = barco;

        Barco barco1 = new Barco(posicionesX[1], posicionesY[1], 50, 100, 3, rutasImagenes[1], panel);
        barcos[1] = barco1;

        Barco barco2 = new Barco(posicionesX[2], posicionesY[2], 50, 100, 3, rutasImagenes[2], panel);
        barcos[2] = barco2;

        Barco barco3 = new Barco(posicionesX[3], posicionesY[3], 50, 100, 4, rutasImagenes[3], panel);
        barcos[3] = barco3;

        Barco barco4 = new Barco(posicionesX[4], posicionesY[4], 50, 100, 5, rutasImagenes[4], panel);
        barcos[4] = barco4;

    }*/

    // Método para crear barcos aleatorios
    public void crearBarcosAleatorios(JPanel panel, String[] rutasImagenes) {
        Random rand = new Random();
        for (int i = 0; i < 5; i++) {
            int size = i + 2; // El tamaño del barco va desde 2
            boolean colocado = false;
            while (!colocado) {
                int x = rand.nextInt(10) + 1; // Generamos una posición aleatoria para X dentro de 1 a 10
                int y = rand.nextInt(10) + 1; // Generamos una posición aleatoria para Y dentro de 1 a 10
                boolean horizontal = rand.nextBoolean(); // Generamos aleatoriamente si el barco será horizontal o vertical
                if (horizontal && puedeColocarHorizontal(size, x, y)) {
                    crearBarcoH(panel, rutasImagenes[i], size, x, y, horizontal);
                    colocado = true;
                } else if (!horizontal && puedeColocarVertical(size, x, y)) {
                    crearBarcoV(panel, rutasImagenes[i], size, x, y, horizontal);
                    colocado = true;
                }
            }
        }
    }

    private boolean puedeColocarHorizontal(int size, int x, int y) {

        if (x + size > 11) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (tableroM[x + i][y] != 0) {
                return false;
            }
        }
        return true;
    }

    private boolean puedeColocarVertical(int size, int x, int y) {

        if (y + size > 11) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (tableroM[x][y + i] != 0) {
                return false;
            }
        }
        return true;
    }

    private void crearBarcoV(JPanel panel, String rutaImagen, int size, int x, int y, boolean horizontal) {
        Barco barco = new Barco(((x - 1) * 31.09) + 32, ((y - 1) * 31.09) + 32, 50, 100, size, rutaImagen, panel);
        if (!horizontal) {
            barco.setRotated(true);
        }
        barcos[size - 2] = barco;

        for (int i = 0; i < size; i++) {
            tableroM[x][y + i] = 1;
        }
    }

    private void crearBarcoH(JPanel panel, String rutaImagen, int size, int x, int y, boolean horizontal) {
        Barco barco = new Barco(((x - 1) * 31.09) + 32, ((y - 1) * 31.09) + 32, 50, 100, size, rutaImagen, panel);
        if (!horizontal) {
            barco.setRotated(true);
        }
        barcos[size - 2] = barco;
        for (int i = 0; i < size; i++) {
            tableroM[x + i][y] = 1;
        }
    }


    public Barco[] getBarcos() {
        return barcos;
    }

    public void setBarcos(Barco[] barcos) {
        this.barcos = barcos;
    }
}
