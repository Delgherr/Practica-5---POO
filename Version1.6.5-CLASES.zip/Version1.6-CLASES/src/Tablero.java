import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tablero extends JFrame {

    public static JButton[][] tablero1;
    //private JButton[][] tablero1;
    private JButton[][] tablero2;
    private JButton[] barcos;
    private JButton comenzarPartida;
    private JButton rotar;
    private boolean vertical = false; // Indica si el barco se debe colocar de forma vertical o horizontal
    private Barco barco;

    private boolean[][] ocupado1 = new boolean[10][10]; // Indica si una celda del tablero 1 está ocupada
    private boolean[][] ocupado2 = new boolean[10][10]; // Indica si una celda del tablero 2 está ocupada



    public Tablero(Barco barco) {

        this.barco = barco;

        setTitle("Tablero de Batalla");
        setSize(1000, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear tableros
        JPanel panelTablero1 = new JPanel(new GridLayout(10, 10));
        JPanel panelTablero2 = new JPanel(new GridLayout(10, 10));

        tablero1 = new JButton[10][10];
        tablero2 = new JButton[10][10];

        // Crear botones de barcos
        JPanel panelBarcos = new JPanel(new GridLayout(5, 1));
        barcos = new JButton[5];
        barcos[0] = new JButton("Barco 2");
        barcos[1] = new JButton("Barco 3");
        barcos[2] = new JButton("Barco 3");
        barcos[3] = new JButton("Barco 4");
        barcos[4] = new JButton("Barco 5");

        for (JButton b : barcos) {
            panelBarcos.add(b);
            b.addActionListener(e -> {
                int indiceBarco = getIndex(barcos,b);
                barco.manejarClicBarco(indiceBarco);
                resetBarco(barco.getBarcoSeleccionado());
            });
        }

      /*  int[] barcosRestantes = barco.getBarcosRestantes();
        final int[] barcoSeleccionado = {barco.getBarcoSeleccionado()};

        for (JButton b : barcos) {
            panelBarcos.add(b);
            b.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int indiceBarco = getIndex(barcos, b);
                    if (barcosRestantes[indiceBarco] > 0) {
                        if (barcoSeleccionado[0] != indiceBarco) {
                            barcoSeleccionado[0] = indiceBarco;
                            resetBarco(barcoSeleccionado[0]);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Ya no quedan barcos de este tipo.", "Atención", JOptionPane.WARNING_MESSAGE);
                    }
                }
            });
        }*/

        // Agregar botones al tablero

        Juego juego = new Juego(this);

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                tablero1[i][j] = new JButton();
                tablero1[i][j].setBackground(Color.BLUE);
                int finalI = i;
                int finalJ = j;
                tablero1[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (barco.getBarcoSeleccionado() != -1 && comenzarPartida.isEnabled()) {
                            int[] TAMANOS = barco.getTAMANOS();
                            barco.colocarBarco(finalI, finalJ, tablero1, ocupado1, TAMANOS[barco.getBarcoSeleccionado()]);
                        }
                    }
                });
                panelTablero1.add(tablero1[i][j]);


                tablero2[i][j] = new JButton();
                tablero2[i][j].setBackground(new Color(01, 01, 01)); // Gris oscuro
                int finalI1 = i;
                int finalJ1 = j;
                tablero2[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (!comenzarPartida.isEnabled()) {
                            juego.atacar(finalI1, finalJ1, tablero2);
                            juego.turnoComputadora();
                        }
                    }
                });
                panelTablero2.add(tablero2[i][j]);
            }
        }

        // Crear contenedor para los tableros
        JPanel tablerosPanel = new JPanel(new GridLayout(1, 2));
        tablerosPanel.add(panelTablero1);
        tablerosPanel.add(panelTablero2);

        // Añadir componentes al frame
        add(tablerosPanel, BorderLayout.CENTER);
        add(panelBarcos, BorderLayout.WEST);

        /// Agregar botón de rotación
        rotar = new JButton("Rotar");
        rotar.addActionListener(e -> {
            if (barco.getBarcoSeleccionado() != -1) {
                vertical = !vertical; // Cambia el estado de la variable vertical
                barco.setVertical(vertical); // Actualiza el estado de la variable vertical en el objeto Barco
                barco.resetBarco(tablero1,ocupado1,barco.getBarcoSeleccionado() ); // Actualiza la orientación de los barcos en el tablero
            } else {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione un barco antes de rotarlo.", "Atención", JOptionPane.WARNING_MESSAGE);
            }
        });






        // Botón para comenzar la partida
        comenzarPartida = new JButton("Comenzar Partida");
        comenzarPartida.addActionListener(e -> {
            comenzarPartida.setEnabled(false);
            rotar.setEnabled(false);
            for (JButton barcco : barcos) {
                barcco.setEnabled(false);
            }
            barco.colocarBarcosAleatorios(tablero2, ocupado2);
        });

        JPanel botonesPanel = new JPanel();
        botonesPanel.add(rotar);
        botonesPanel.add(comenzarPartida);

        add(botonesPanel, BorderLayout.SOUTH);
    }



    public void resetBarco(int barcoIndex) {
        if (barcoIndex != -1) {
            int[][] barcosColocados = barco.getBarcosColocados();
            if (barcosColocados[barcoIndex][0] != 0) {
                for (int i = 0; i < 10; i++) {
                    for (int j = 0; j < 10; j++) {
                        if (tablero1[i][j].getBackground() == Color.BLACK) {
                            tablero1[i][j].setBackground(Color.BLUE);
                            ocupado1[i][j] = false;
                        }
                    }
                }
                barcosColocados[barcoIndex][0] = 0;
                int[] barcosRestantes = barco.getBarcosRestantes();
                barcosRestantes[barcoIndex] = 1;
            }
        }

    }

    // Función para obtener el índice de un JButton en un array
    private int getIndex(JButton[] array, JButton button) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == button) {
                return i;
            }
        }
        return -1;
    }


    public JButton[][] getTablero1() {
        return tablero1;
    }

    public void setTablero1(JButton[][] tablero1) {
        this.tablero1 = tablero1;
    }



    public void setTablero2(JButton[][] tablero2) {
        this.tablero2 = tablero2;
    }

    public JButton[] getBarcos() {
        return barcos;
    }


    public void setBarcos(JButton[] barcos) {
        this.barcos = barcos;
    }

    public JButton getComenzarPartida() {
        return comenzarPartida;
    }

    public void setComenzarPartida(JButton comenzarPartida) {
        this.comenzarPartida = comenzarPartida;
    }

    public JButton getRotar() {
        return rotar;
    }

    public void setRotar(JButton rotar) {
        this.rotar = rotar;
    }

    public boolean[][] getOcupado1() {
        return ocupado1;
    }

    public void setOcupado1(boolean[][] ocupado1) {
        this.ocupado1 = ocupado1;
    }

    public boolean[][] getOcupado2() {
        return ocupado2;
    }

    public void setOcupado2(boolean[][] ocupado2) {
        this.ocupado2 = ocupado2;
    }




}
