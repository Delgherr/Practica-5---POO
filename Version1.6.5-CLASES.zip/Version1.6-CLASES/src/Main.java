public class Main {
    public static void main(String[] args) {
        Barco barco = new Barco();
        Tablero tablero = new Tablero(barco);
        tablero.setVisible(true);
    }
}