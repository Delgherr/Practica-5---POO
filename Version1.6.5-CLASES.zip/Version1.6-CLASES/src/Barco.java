import javax.swing.*;
import java.awt.*;
import java.util.Random;


public class Barco extends JFrame {

    private int barcoSeleccionado = -1; // -1 significa que no se ha seleccionado ningún barco
    private boolean vertical = false; // Indica si el barco se debe colocar de forma vertical o horizontal
    private int[][] barcosColocados = new int[5][2]; // Indica los barcos colocados en el tablero 1 (tipo, tamaño)
    private int[] TAMANOS = {2, 3, 3, 4, 5}; // Tamaños de los barcos
    private int[] barcosRestantes = {1, 1, 1, 1, 1}; // Barcos restantes por tipo



    // Método para resetear el barco seleccionado si ya estaba colocado
    public void resetBarco(JButton[][] tablero1, boolean[][] ocupado1, int barcoIndex) {
        if (barcosColocados[barcoIndex][0] != 0) {
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    if (tablero1[i][j].getBackground() == Color.BLACK) {
                        tablero1[i][j].setBackground(Color.BLUE);
                        ocupado1[i][j] = false;
                    }
                }
            }
            barcosColocados[barcoIndex][0] = 0;
            int[] barcosRestantes = getBarcosRestantes(); // Cambiar a método getter
            barcosRestantes[barcoIndex] = 1;
        }
    }



    // Método para colocar un barco en el tablero
    public void colocarBarco(int fila, int columna, JButton[][] tablero, boolean[][] ocupado, int size) {
        if (!vertical && columna <= 9 - size + 1) {
            for (int i = columna; i < columna + size; i++) {
                if (ocupado[fila][i]) {
                    JOptionPane.showMessageDialog(null, "Ya hay un barco en esta posición.", "Atención", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
            for (int i = columna; i < columna + size; i++) {
                tablero[fila][i].setBackground(Color.BLACK);
                ocupado[fila][i] = true;
            }
            barcosColocados[barcoSeleccionado][0] = 1;
            barcosRestantes[barcoSeleccionado] = 0;
            barcoSeleccionado = -1;
        } else if (vertical && fila <= 9 - size + 1) {
            for (int i = fila; i < fila + size; i++) {
                if (ocupado[i][columna]) {
                    JOptionPane.showMessageDialog(null, "Ya hay un barco en esta posición.", "Atención", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
            for (int i = fila; i < fila + size; i++) {
                tablero[i][columna].setBackground(Color.BLACK);
                ocupado[i][columna] = true;
            }
            barcosColocados[barcoSeleccionado][0] = 1;
            barcosRestantes[barcoSeleccionado] = 0;
            barcoSeleccionado = -1;
        } else {
            JOptionPane.showMessageDialog(null, "El barco no cabe en esta posición.", "Atención", JOptionPane.WARNING_MESSAGE);
        }
    }


    // Método para verificar si hay colisión al colocar un barco
    public boolean hayColision(int fila, int columna, int size, boolean vertical, boolean[][] ocupado) {
        if (vertical) {
            for (int i = fila; i < fila + size; i++) {
                if (ocupado[i][columna]) {
                    return true;
                }
            }
        } else {
            for (int j = columna; j < columna + size; j++) {
                if (ocupado[fila][j]) {
                    return true;
                }
            }
        }
        return false;
    }

    // Método para colocar barcos aleatorios en el tablero
    public void colocarBarcosAleatorios(JButton[][] tablero, boolean[][] ocupado) {
        Random rand = new Random();
        for (int k = 0; k < 5; k++) {
            int i, j;
            int size = TAMANOS[k];
            boolean vertical = rand.nextBoolean();
            if (vertical) {
                do {
                    i = rand.nextInt(10 - size + 1);
                    j = rand.nextInt(10);
                } while (hayColision(i, j, size, vertical, ocupado));
                for (int l = i; l < i + size; l++) {
                    tablero[l][j].setBackground(Color.BLACK);
                    ocupado[l][j] = true;
                }
            } else {
                do {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10 - size + 1);
                } while (hayColision(i, j, size, vertical, ocupado));
                for (int l = j; l < j + size; l++) {
                    tablero[i][l].setBackground(Color.BLACK);
                    ocupado[i][l] = true;
                }
            }
        }
    }




    public int getBarcoSeleccionado() {
        return barcoSeleccionado;
    }

    public void setBarcoSeleccionado(int barcoSeleccionado) {
        this.barcoSeleccionado = barcoSeleccionado;
    }

    public int[] getBarcosRestantes() {
        return barcosRestantes;
    }

    public void setBarcosRestantes(int[] barcosRestantes) {
        this.barcosRestantes = barcosRestantes;
    }

    public int[] getTAMANOS() {
        return TAMANOS;
    }

    public boolean isVertical() {
        return vertical;
    }

    public void setVertical(boolean vertical) {
        this.vertical = vertical;
    }

    public int[][] getBarcosColocados() {
        return barcosColocados;
    }

    public void setBarcosColocados(int[][] barcosColocados) {
        this.barcosColocados = barcosColocados;
    }

    public void manejarClicBarco(int indice) {
        if (barcosRestantes[indice] != 0) {
            barcoSeleccionado = indice;
        } else {
            JOptionPane.showMessageDialog(null, "Ya has colocado todos los barcos de este tipo.", "Atención", JOptionPane.WARNING_MESSAGE);
        }
    }


}

